package com.sudhansu.weatherinfo;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.view.View;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.rule.ActivityTestRule;

import com.sudhansu.weatherinfo.util.WeatherDetails;


import org.junit.Rule;
import org.junit.Test;


import org.junit.Assert;


import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.junit.Assert.assertEquals;

public class WeatherInfoTest {
    public WeatherDetails weatherDetails;
    public Resources resources;



    @Rule
    public ActivityTestRule<MainActivity> mActivityRule = new ActivityTestRule<>(MainActivity.class);

    public WeatherInfoTest(){
        weatherDetails = WeatherApplication.getWeatherDetailsFromPref();
        resources = ApplicationProvider.getApplicationContext().getResources();
    }


    @Test
    public void useAppContext() {
        // Context of the app under test.
        Context appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();
        assertEquals("com.sudhansu.weatherinfo", appContext.getPackageName());
    }

    @Test
    public void testIsLocationIsValid() throws InterruptedException {
        Thread.sleep(3000);
        onView(withId(R.id.currentLocationTv)).check(matches(withText(weatherDetails.getCurrentLocation())));
    }

    @Test
    public void testIsTimeIsValid() throws InterruptedException{
        Thread.sleep(3000);
        onView(withId(R.id.timeDateTv)).check(matches(withText(weatherDetails.getTime())));
    }

    @Test
    public void testIsTemperatureIsValid() throws InterruptedException{
        Thread.sleep(3000);
        onView(withId(R.id.temperatureTv)).check(matches(withText(weatherDetails.getTemperature()+resources.getString(R.string.degree_only))));
    }

    @Test
    public void testIsFeelsLikeTempIsValid() throws InterruptedException{
        Thread.sleep(3000);
        onView(withId(R.id.feelsLikeTv)).check(matches(withText("Feels like: "+weatherDetails.getFeelsLikeTemp()+resources.getString(R.string.degree_only))));
    }


    @Test
    public void testIsDescriptionIsValid() throws InterruptedException{
        Thread.sleep(3000);
        onView(withId(R.id.mainDesriptionTv)).check(matches(withText(weatherDetails.getDescription())));
    }

    @Test
    public void testIsSubDesriptionIsValid() throws InterruptedException{
        Thread.sleep(3000);
        onView(withId(R.id.desriptionTv)).check(matches(withText(weatherDetails.getSubDescription())));
    }

    @Test
    public void testIsMinTempIsValid() throws InterruptedException{
        Thread.sleep(3000);
        onView(withId(R.id.minTempTv)).check(matches(withText("Min Temp\n"+weatherDetails.getMinTemp()+resources.getString(R.string.degree_only))));
    }

    @Test
    public void testIsMaxTempIsValid() throws InterruptedException{
        Thread.sleep(3000);
        onView(withId(R.id.maxTempTv)).check(matches(withText("Max Temp\n"+weatherDetails.getMaxTemp()+resources.getString(R.string.degree_only))));
    }

    @Test
    public void testIsPressureIsValid() throws InterruptedException{
        Thread.sleep(3000);
        onView(withId(R.id.pressureTv)).check(matches(withText("Pressure\n"+weatherDetails.getPressure())));
    }

    @Test
    public void testIsHumidityIsValid() throws InterruptedException{
        Thread.sleep(3000);
        onView(withId(R.id.humodityTv)).check(matches(withText("Humidity\n"+weatherDetails.getHumidity()+"%")));
    }

    @Test
    public void testIsWindSpeedIsValid() throws InterruptedException{
        Thread.sleep(3000);
        onView(withId(R.id.windSpeedTv)).check(matches(withText("Wind Speed\n"+weatherDetails.getWindSpeed())));
    }

    @Test
    public void testIsWindDegreeIsValid() throws InterruptedException{
        Thread.sleep(3000);
        onView(withId(R.id.windDegreeTv)).check(matches(withText("Wind Degree\n"+weatherDetails.getWindDegree()+resources.getString(R.string.degree_only))));
    }

    @Test
    public void testIsSunriseIsValid() throws InterruptedException{
        Thread.sleep(3000);
        onView(withId(R.id.suriseTv)).check(matches(withText("Sunrise\n"+weatherDetails.getSunriseTime())));
    }

    @Test
    public void testIsSunsetIsValid() throws InterruptedException{
        Thread.sleep(3000);
        onView(withId(R.id.sunsetTv)).check(matches(withText("Sunset\n"+weatherDetails.getSunsetTime())));
    }


}
