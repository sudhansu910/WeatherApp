package com.sudhansu.weatherinfo.weather;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.util.Log;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.sudhansu.weatherinfo.WeatherApplication;
import com.sudhansu.weatherinfo.util.WeatherLocationService;

public class WeatherJobService extends JobService {
    private static final String TAG = WeatherJobService.class.getSimpleName();


    @Override
    public boolean onStartJob(JobParameters jobParameters) {
        Log.d(TAG, "onStartJob: jobParameters = ");
        if(WeatherApplication.isWifiConnected()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(new Intent(this, WeatherLocationService.class));
            } else {
                startService(new Intent(this, WeatherLocationService.class));
            }
        }else{
            Log.v(TAG, "Wifi is not connected. Aborted");
            WeatherApplication.scheduleJob(this);
        }
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters jobParameters) {
        Log.d(TAG, "onStopJob: jobParameters = ");
        return true;
    }


}
