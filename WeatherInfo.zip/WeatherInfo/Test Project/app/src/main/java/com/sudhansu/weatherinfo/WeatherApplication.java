package com.sudhansu.weatherinfo;

import android.app.Application;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.content.res.Resources;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.preference.PreferenceManager;
import android.util.Log;

import com.sudhansu.weatherinfo.util.WeatherDetails;
import com.sudhansu.weatherinfo.weather.WeatherJobService;

import java.lang.ref.WeakReference;

public class WeatherApplication extends Application {
    private static final String TAG = WeatherApplication.class.getSimpleName();

    private static WeakReference<Context> mContext;
    private static Resources resources;

    public static final int JOB_ID = 1002;
    public static final String WEATHER_DETAILS = "WEATHER_DETAILS";
    public static final String WEATHER_BROADCAST_ACTION = "com.sudhansu.weatherinfo.openweathermap";
    public static final int REFRESH_INTERVAL = 2* 60 * 60 * 1000; //2 hours
   // public static final int REFRESH_INTERVAL = 20 * 1000; //2 hours
    public static JobInfo jobInfo;


    @Override
    public void onCreate() {
        super.onCreate();
        mContext = new WeakReference<>(this);
        resources = getResources();
    }

    public static Context getContext() {
        return mContext.get();
    }

    public static Resources getAppResources() {
        return resources;
    }

    public static void setStringPreference(String key, String value) {
        PreferenceManager.getDefaultSharedPreferences(getContext()).edit().putString(key, value).apply();
    }

    public static String getStringPreference(String key) {
        return PreferenceManager.getDefaultSharedPreferences(getContext()).getString(key, "");
    }

    public static void setWeatherDetailsToPref(WeatherDetails weatherDetails){
        Log.v("setWeatherDetailsToPref",""+weatherDetails);

        setStringPreference(WeatherApplication.getAppResources().getString(R.string.current_location), weatherDetails.getCurrentLocation());
        setStringPreference(getContext().getResources().getString(R.string.time), weatherDetails.getTime());
        setStringPreference(getContext().getResources().getString(R.string.temperature), weatherDetails.getTemperature());
        setStringPreference(getContext().getResources().getString(R.string.feelsLikeTemp), weatherDetails.getFeelsLikeTemp());
        setStringPreference(getContext().getResources().getString(R.string.description), weatherDetails.getDescription());
        setStringPreference(getContext().getResources().getString(R.string.subDescription), weatherDetails.getSubDescription());
        setStringPreference(getContext().getResources().getString(R.string.minTemp), weatherDetails.getMinTemp());
        setStringPreference(getContext().getResources().getString(R.string.maxTemp), weatherDetails.getMaxTemp());
        setStringPreference(getContext().getResources().getString(R.string.pressure), weatherDetails.getPressure());
        setStringPreference(getContext().getResources().getString(R.string.humidity), weatherDetails.getHumidity());
        setStringPreference(getContext().getResources().getString(R.string.windSpeed), weatherDetails.getWindSpeed());
        setStringPreference(getContext().getResources().getString(R.string.windDegree), weatherDetails.getWindDegree());
        setStringPreference(getContext().getResources().getString(R.string.sunriseTime), weatherDetails.getSunriseTime());
        setStringPreference(getContext().getResources().getString(R.string.sunsetTime), weatherDetails.getSunsetTime());

    }

    public static WeatherDetails getWeatherDetailsFromPref(){
        WeatherDetails weatherDetails = new WeatherDetails();

        weatherDetails.setCurrentLocation(getStringPreference(getContext().getResources().getString(R.string.current_location)));
        weatherDetails.setTime(getStringPreference(getContext().getResources().getString(R.string.time)));
        weatherDetails.setTemperature(getStringPreference(getContext().getResources().getString(R.string.temperature)));
        weatherDetails.setFeelsLikeTemp(getStringPreference(getContext().getResources().getString(R.string.feelsLikeTemp)));
        weatherDetails.setDescription(getStringPreference(getContext().getResources().getString(R.string.description)));
        weatherDetails.setSubDescription(getStringPreference(getContext().getResources().getString(R.string.subDescription)));
        weatherDetails.setMinTemp(getStringPreference(getContext().getResources().getString(R.string.minTemp)));
        weatherDetails.setMaxTemp(getStringPreference(getContext().getResources().getString(R.string.maxTemp)));
        weatherDetails.setPressure(getStringPreference(getContext().getResources().getString(R.string.pressure)));
        weatherDetails.setHumidity(getStringPreference(getContext().getResources().getString(R.string.humidity)));
        weatherDetails.setWindSpeed(getStringPreference(getContext().getResources().getString(R.string.windSpeed)));
        weatherDetails.setWindDegree(getStringPreference(getContext().getResources().getString(R.string.windDegree)));
        weatherDetails.setSunriseTime(getStringPreference(getContext().getResources().getString(R.string.sunriseTime)));
        weatherDetails.setSunsetTime(getStringPreference(getContext().getResources().getString(R.string.sunsetTime)));

        return weatherDetails;
    }

    public static void scheduleJob(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            jobInfo = new JobInfo.Builder(JOB_ID, new ComponentName( context.getPackageName(), WeatherJobService.class.getName()))
                    .setMinimumLatency(REFRESH_INTERVAL)
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .build();
        } else {
            jobInfo = new JobInfo.Builder(JOB_ID, new ComponentName( context.getPackageName(), WeatherJobService.class.getName()))
                    .setPeriodic(REFRESH_INTERVAL)
                    .build();
        }
        JobScheduler jobScheduler = (JobScheduler) context.getSystemService( Context.JOB_SCHEDULER_SERVICE );
        jobScheduler.schedule(jobInfo);
    }

    public static boolean isJobServiceOn( Context context ) {
        JobScheduler scheduler = (JobScheduler) context.getSystemService( Context.JOB_SCHEDULER_SERVICE ) ;
        boolean hasBeenScheduled = false ;
        for ( JobInfo jobInfo : scheduler.getAllPendingJobs() ) {
            if ( jobInfo.getId() == JOB_ID ) {
                hasBeenScheduled = true ;
                break ;
            }
        }
        return hasBeenScheduled ;
    }

    public static boolean isWifiConnected(){
        ConnectivityManager connManager = (ConnectivityManager) getContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo mWifi = connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        if (mWifi.isConnected()) {
            return  true;
        }
        return false;
    }


}
