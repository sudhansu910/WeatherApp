package com.sudhansu.weatherinfo.weather;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;

import com.sudhansu.weatherinfo.WeatherApplication;
import com.sudhansu.weatherinfo.util.Http;
import com.sudhansu.weatherinfo.util.WeatherDetails;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import static com.sudhansu.weatherinfo.WeatherApplication.WEATHER_BROADCAST_ACTION;
import static com.sudhansu.weatherinfo.WeatherApplication.WEATHER_DETAILS;

public class WeatherReadTask extends AsyncTask<Object, Integer, String> {
    private String weatherData = null;
    private Context context;

    public WeatherReadTask(Context context){
        this.context = context;
    }

    @Override
    protected String doInBackground(Object... inputObj) {
        try {
            String weatherUrl = (String) inputObj[0];
            Log.d("weatherData url", weatherUrl);
            Http http = new Http();
            weatherData = http.read(weatherUrl);
        } catch (Exception e) {
            Log.d("weatherData Read Task", e.toString());
        }
        return weatherData;
    }

    @Override
    protected void onPostExecute(String result) {
        Log.v("weatherData","Result: "+result);
        WeatherDetails weatherDetails = null;
        try {
            if(result != null && !result.equals("")){
                weatherDetails = new WeatherData().parse(new JSONObject(result));

                if(!weatherDetails.getTime().equals(""))weatherDetails.setTime(getDate(Long.parseLong(weatherDetails.getTime()), "hh:mm aa"));
                if(!weatherDetails.getSunriseTime().equals(""))weatherDetails.setSunriseTime(getDate(Long.parseLong(weatherDetails.getSunriseTime()), "hh:mm aa"));
                if(!weatherDetails.getSunsetTime().equals(""))weatherDetails.setSunsetTime(getDate(Long.parseLong(weatherDetails.getSunsetTime()), "hh:mm aa"));

                WeatherApplication.setWeatherDetailsToPref(weatherDetails);

                Intent intent1 = new Intent();
                intent1.setAction(WEATHER_BROADCAST_ACTION);
                intent1.putExtra(WEATHER_DETAILS, weatherDetails);
                context.sendBroadcast(intent1);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public static String getDate(long milliSeconds, String dateFormat){
        SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(milliSeconds);
        return formatter.format(calendar.getTime());
    }
}