package com.sudhansu.weatherinfo;


import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.sudhansu.weatherinfo.util.WeatherDetails;
import com.sudhansu.weatherinfo.util.WeatherLocationService;
import com.sudhansu.weatherinfo.weather.WeatherReadTask;

import static com.sudhansu.weatherinfo.WeatherApplication.WEATHER_BROADCAST_ACTION;
import static com.sudhansu.weatherinfo.WeatherApplication.WEATHER_DETAILS;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = MainActivity.class.getSimpleName();

    private  BroadcastReceiver broadcastReceiver;
    private TextView locationTv, timeTv, temperatureTv, feelsLikeTv, descriptionTv,
            subDescriptionTv, minTempTv, maxTempTv, pressureTv, humidityTv, windSpeedTv, windDegreeTv, sunriseTv, sunsetTv;
    private final int PERMISSIONS_REQUEST_READ_LOCATION = 1009;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        locationTv = (TextView) findViewById(R.id.currentLocationTv);
        timeTv = (TextView) findViewById(R.id.timeDateTv);
        temperatureTv = (TextView) findViewById(R.id.temperatureTv);
        feelsLikeTv = (TextView) findViewById(R.id.feelsLikeTv);
        descriptionTv = (TextView) findViewById(R.id.mainDesriptionTv);
        subDescriptionTv = (TextView) findViewById(R.id.desriptionTv);
        minTempTv = (TextView) findViewById(R.id.minTempTv);
        maxTempTv = (TextView) findViewById(R.id.maxTempTv);
        pressureTv = (TextView) findViewById(R.id.pressureTv);
        humidityTv = (TextView) findViewById(R.id.humodityTv);
        windSpeedTv = (TextView) findViewById(R.id.windSpeedTv);
        windDegreeTv = (TextView) findViewById(R.id.windDegreeTv);
        sunriseTv = (TextView) findViewById(R.id.suriseTv);
        sunsetTv = (TextView) findViewById(R.id.sunsetTv);

        try {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                requestPermissionForLocation();
            }else{
                startWeatherService();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void requestPermissionForLocation(){
        if(Build.VERSION.SDK_INT >= 23 &&
                ContextCompat.checkSelfPermission( this, Manifest.permission.ACCESS_COARSE_LOCATION ) != PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission( this, Manifest.permission.ACCESS_FINE_LOCATION ) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions((Activity)this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, PERMISSIONS_REQUEST_READ_LOCATION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == PERMISSIONS_REQUEST_READ_LOCATION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startWeatherService();
            } else {
                finish();
            }
        }else{
            finish();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        broadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                WeatherDetails weatherDetails = (WeatherDetails)intent.getSerializableExtra(WEATHER_DETAILS);
                Log.v(TAG, "updateWeather: "+ weatherDetails.getCurrentLocation());
                updateWeatherDetails(weatherDetails);
            }
        };

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(WEATHER_BROADCAST_ACTION);
        registerReceiver(broadcastReceiver, intentFilter);

    }

    public void startWeatherService(){
        if(!WeatherApplication.isJobServiceOn(this)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(new Intent(this, WeatherLocationService.class));
            } else {
                startService(new Intent(this, WeatherLocationService.class));
            }
        }else{
            updateWeatherDetails(WeatherApplication.getWeatherDetailsFromPref());
        }
    }


    private void updateWeatherDetails(WeatherDetails weatherDetails) {
        locationTv.setText(weatherDetails.getCurrentLocation());
        timeTv.setText(weatherDetails.getTime());
        temperatureTv.setText(weatherDetails.getTemperature()+getResources().getString(R.string.degree_only));
        feelsLikeTv.setText("Feels like: "+weatherDetails.getFeelsLikeTemp()+getResources().getString(R.string.degree_only));
        descriptionTv.setText(weatherDetails.getDescription());
        subDescriptionTv.setText(weatherDetails.getSubDescription());
        minTempTv.setText("Min Temp\n"+weatherDetails.getMinTemp()+getResources().getString(R.string.degree_only));
        maxTempTv.setText("Max Temp\n"+weatherDetails.getMaxTemp()+getResources().getString(R.string.degree_only));
        pressureTv.setText("Pressure\n"+weatherDetails.getPressure());
        humidityTv.setText("Humidity\n"+weatherDetails.getHumidity()+"%");
        windSpeedTv.setText("Wind Speed\n"+weatherDetails.getWindSpeed());
        windDegreeTv.setText("Wind Degree\n"+weatherDetails.getWindDegree()+getResources().getString(R.string.degree_only));
        sunriseTv.setText("Sunrise\n"+weatherDetails.getSunriseTime());
        sunsetTv.setText("Sunset\n"+weatherDetails.getSunsetTime());
    }

    @Override
    protected void onStop() {
        super.onStop();
        if(broadcastReceiver != null) {
            unregisterReceiver(broadcastReceiver);
            broadcastReceiver = null;
        }
    }
}