package com.sudhansu.weatherinfo.weather;

import com.sudhansu.weatherinfo.util.WeatherDetails;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class WeatherData {
    public static final String TAG = WeatherData.class.getSimpleName();

    public WeatherDetails parse(JSONObject jsonObject) {
        JSONObject jsonObjectMain, jsonObjWind, jsonObjSys, jsonObjWeather;
        JSONArray jsonArrayWeather;
        WeatherDetails weatherDetails = new WeatherDetails();

        try {
            weatherDetails.setCurrentLocation(jsonObject.getString("name"));
            weatherDetails.setTime(jsonObject.getString("dt"));

            jsonObjectMain = jsonObject.getJSONObject("main");
            weatherDetails.setTemperature(jsonObjectMain.getString("temp"));
            weatherDetails.setFeelsLikeTemp(jsonObjectMain.getString("feels_like"));
            weatherDetails.setMinTemp(jsonObjectMain.getString("temp_min"));
            weatherDetails.setMaxTemp(jsonObjectMain.getString("temp_max"));
            weatherDetails.setPressure(jsonObjectMain.getString("pressure"));
            weatherDetails.setHumidity(jsonObjectMain.getString("humidity"));

            jsonObjWind = jsonObject.getJSONObject("wind");
            weatherDetails.setWindSpeed(jsonObjWind.getString("speed"));
            weatherDetails.setWindDegree(jsonObjWind.getString("deg"));

            jsonObjSys = jsonObject.getJSONObject("sys");
            weatherDetails.setSunriseTime(jsonObjSys.getString("sunrise"));
            weatherDetails.setSunsetTime(jsonObjSys.getString("sunset"));

            jsonArrayWeather = jsonObject.getJSONArray("weather");
            jsonObjWeather = jsonArrayWeather.getJSONObject(0);

            weatherDetails.setDescription(jsonObjWeather.getString("main"));
            weatherDetails.setSubDescription(jsonObjWeather.getString("description"));

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return weatherDetails;
    }
}
