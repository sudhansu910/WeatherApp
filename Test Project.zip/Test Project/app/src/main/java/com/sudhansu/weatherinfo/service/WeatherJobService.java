package com.sudhansu.weatherinfo.service;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;

import android.content.Intent;
import android.util.Log;


import com.sudhansu.weatherinfo.component.DaggerWeatherJobComponent;
import com.sudhansu.weatherinfo.module.WeatherJobModule;
import com.sudhansu.weatherinfo.util.Util;

import javax.inject.Inject;

public class WeatherJobService extends JobService {
    private static final String TAG = WeatherJobService.class.getName();

    @Inject JobScheduler jobScheduler;
    @Inject JobInfo jobInfo;

    @Override
    public boolean onStartJob(JobParameters jobParameters) {
        Log.v(TAG, "onStartJob");
        DaggerWeatherJobComponent.builder().weatherJobModule(new WeatherJobModule(this)).build().inject(this);
        if(Util.isWifiConnected(this)) {
            Intent intent = new Intent(Util.weather_Job_scheduler_broadcast);
            sendBroadcast(intent);
        }else{
            jobScheduler.schedule(jobInfo);
        }

        return true;
    }

    @Override
    public boolean onStopJob(JobParameters jobParameters) {
        Log.v(TAG, "onStopJob");
        return true;
    }

}
