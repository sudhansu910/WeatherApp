package com.sudhansu.weatherinfo;


import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResult;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.sudhansu.weatherinfo.component.DaggerWeatherActivityComponent;
import com.sudhansu.weatherinfo.databinding.ActivityMainBinding;
import com.sudhansu.weatherinfo.module.WeatherMvpModule;
import com.sudhansu.weatherinfo.mvp.WeatherContract;
import com.sudhansu.weatherinfo.mvp.WeatherModel;
import com.sudhansu.weatherinfo.mvp.WeatherPresenter;
import com.sudhansu.weatherinfo.util.Util;
import com.sudhansu.weatherinfo.util.WeatherDetails;

import javax.inject.Inject;

public class MainActivity extends AppCompatActivity implements WeatherContract.View{
    private static final String TAG = MainActivity.class.getSimpleName();

    @Inject Context mContext;
    @Inject WeatherPresenter weatherPresenter;
    @Inject GoogleApiClient googleApiClient;
    @Inject LocationRequest locationRequest;
    @Inject LocationSettingsRequest.Builder builder;


    private ActivityMainBinding activityMainBinding;
    private final int PERMISSIONS_REQUEST_READ_LOCATION = 1009;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityMainBinding = DataBindingUtil.setContentView(this, R.layout.activity_main);

        DaggerWeatherActivityComponent.builder()
                .weatherAppComponent(WeatherApplication.get(this).getWeatherAppComponent())
                .weatherMvpModule(new WeatherMvpModule(this, new WeatherModel())).build().inject(this);
        weatherPresenter.initialiseWeatherInfo();

        registerReceiver(mMessageReceiver, new IntentFilter(Util.weather_Job_scheduler_broadcast));
    }

    @Override
    public void checkLocationPermission() {
        try {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                requestPermissionForLocation();
            }else{
                weatherPresenter.startWeatherInfoService();
            }
        } catch (Exception e) {
            e.printStackTrace();
            onFailure(e.toString());
        }
    }

    @Override
    public void enableGpsLocation() {
        showGpsLocationSettingsAlert();
    }

    public void requestPermissionForLocation(){
        if(Build.VERSION.SDK_INT >= 23 &&
                ContextCompat.checkSelfPermission( this, Manifest.permission.ACCESS_COARSE_LOCATION ) != PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission( this, Manifest.permission.ACCESS_FINE_LOCATION ) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions((Activity)this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, PERMISSIONS_REQUEST_READ_LOCATION);
        }
    }

    public void showGpsLocationSettingsAlert() {
        googleApiClient.connect();
        PendingResult<LocationSettingsResult> result = LocationServices.SettingsApi.checkLocationSettings(googleApiClient, builder.build());
        result.setResultCallback(new ResultCallback<LocationSettingsResult>() {
            @Override
            public void onResult(LocationSettingsResult result) {
                final Status status = result.getStatus();
                switch (status.getStatusCode()) {
                    case LocationSettingsStatusCodes.SUCCESS:
                        weatherPresenter.startWeatherInfoService();
                        break;
                    case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                        try {
                            status.startResolutionForResult(MainActivity.this, 1009);
                        } catch (IntentSender.SendIntentException e) {
                            finish();
                        }
                        break;
                    case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                        finish();
                        break;
                }
            }
        });
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == PERMISSIONS_REQUEST_READ_LOCATION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                weatherPresenter.startWeatherInfoService();
            } else {
                finish();
            }
        }else{
            finish();
        }
    }

    @Override
    public void onSuccess(WeatherDetails weatherDetails) {
        activityMainBinding.setWeather(weatherDetails);
    }

    @Override
    public void onFailure(String msg) {
        Log.v(TAG, "Error! "+msg);
    }

    private BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if(weatherPresenter != null) {
                weatherPresenter.reStartWeatherInfoService();
            }
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(mMessageReceiver != null)unregisterReceiver(mMessageReceiver);
    }
}