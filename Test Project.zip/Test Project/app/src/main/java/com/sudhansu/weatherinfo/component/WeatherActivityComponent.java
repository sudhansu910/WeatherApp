package com.sudhansu.weatherinfo.component;


import com.sudhansu.weatherinfo.MainActivity;
import com.sudhansu.weatherinfo.module.WeatherMvpModule;

import com.sudhansu.weatherinfo.scope.WeatherActivityScope;

import dagger.Component;

@WeatherActivityScope
@Component(dependencies = WeatherAppComponent.class, modules={WeatherMvpModule.class})
public interface WeatherActivityComponent {
    void inject(MainActivity mainActivity);
}


