package com.sudhansu.weatherinfo;

import android.app.Application;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;

import com.sudhansu.weatherinfo.component.DaggerWeatherAppComponent;
import com.sudhansu.weatherinfo.component.WeatherAppComponent;
import com.sudhansu.weatherinfo.module.WeatherAppModule;
import com.sudhansu.weatherinfo.util.Util;
import com.sudhansu.weatherinfo.util.WeatherDetails;

import javax.inject.Inject;

public class WeatherApplication extends Application {
    private static final String TAG = WeatherApplication.class.getSimpleName();

    private WeatherAppComponent weatherAppComponent;
    @Inject SharedPreferences pref;
    @Inject SharedPreferences.Editor editor;
    @Inject Context context;

    public static WeatherApplication get(Context context) {
        return (WeatherApplication) context.getApplicationContext();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        weatherAppComponent = DaggerWeatherAppComponent.builder().weatherAppModule(new WeatherAppModule(this)).build();
        weatherAppComponent.inject(this);
    }

    public WeatherAppComponent getWeatherAppComponent() {
        return weatherAppComponent;
    }


    public void setWeatherDetailsToPref(WeatherDetails weatherDetails){

        this.editor.putString(context.getString(R.string.current_location), weatherDetails.getName());
        this.editor.putString(context.getString(R.string.time), weatherDetails.getDt());
        this.editor.putString(context.getResources().getString(R.string.temperature), weatherDetails.getTemp());
        this.editor.putString(context.getResources().getString(R.string.feelsLikeTemp), weatherDetails.getFeels_like());
        this.editor.putString(context.getResources().getString(R.string.description), weatherDetails.getMain());
        this.editor.putString(context.getResources().getString(R.string.subDescription), weatherDetails.getDescription());
        this.editor.putString(context.getResources().getString(R.string.minTemp), weatherDetails.getTemp_min());
        this.editor.putString(context.getResources().getString(R.string.maxTemp), weatherDetails.getTemp_max());
        this.editor.putString(context.getResources().getString(R.string.pressure), weatherDetails.getPressure());
        this.editor.putString(context.getResources().getString(R.string.humidity), weatherDetails.getHumidity());
        this.editor.putString(context.getResources().getString(R.string.windSpeed), weatherDetails.getSpeed());
        this.editor.putString(context.getResources().getString(R.string.windDegree), weatherDetails.getDeg());
        this.editor.putString(context.getResources().getString(R.string.sunriseTime), weatherDetails.getSunrise());
        this.editor.putString(context.getResources().getString(R.string.sunsetTime), weatherDetails.getSunset());

        this.editor.commit();
    }

    public WeatherDetails getWeatherDetailsFromPref(){
        WeatherDetails weatherDetails = new WeatherDetails();

        weatherDetails.setName(pref.getString(context.getResources().getString(R.string.current_location), ""));
        weatherDetails.setDt(pref.getString(context.getResources().getString(R.string.time), ""));
        weatherDetails.setTemp(pref.getString(context.getResources().getString(R.string.temperature), ""));
        weatherDetails.setFeels_like(pref.getString(context.getResources().getString(R.string.feelsLikeTemp), ""));
        weatherDetails.setMain(pref.getString(context.getResources().getString(R.string.description), ""));
        weatherDetails.setDescription(pref.getString(context.getResources().getString(R.string.subDescription), ""));
        weatherDetails.setTemp_min(pref.getString(context.getResources().getString(R.string.minTemp), ""));
        weatherDetails.setTemp_max(pref.getString(context.getResources().getString(R.string.maxTemp), ""));
        weatherDetails.setPressure(pref.getString(context.getResources().getString(R.string.pressure), ""));
        weatherDetails.setHumidity(pref.getString(context.getResources().getString(R.string.humidity), ""));
        weatherDetails.setSpeed(pref.getString(context.getResources().getString(R.string.windSpeed), ""));
        weatherDetails.setDeg(pref.getString(context.getResources().getString(R.string.windDegree), ""));
        weatherDetails.setSunrise(pref.getString(context.getResources().getString(R.string.sunriseTime), ""));
        weatherDetails.setSunset(pref.getString(context.getResources().getString(R.string.sunsetTime), ""));

        return weatherDetails;

    }

}
