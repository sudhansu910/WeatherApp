package com.sudhansu.weatherinfo.mvp;

import android.content.Context;

import com.sudhansu.weatherinfo.WeatherApplication;
import com.sudhansu.weatherinfo.util.WeatherDetails;


public class WeatherModel implements WeatherContract.Model {

    @Override
    public void setWeatherToPref(Context context, WeatherDetails weatherDetails) {
        WeatherApplication.get(context).setWeatherDetailsToPref(weatherDetails);
    }

    @Override
    public WeatherDetails updateWeatherFromPref(Context context) {
        return WeatherApplication.get(context).getWeatherDetailsFromPref();
    }
}
