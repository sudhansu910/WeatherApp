package com.sudhansu.weatherinfo.mvp;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;

import com.sudhansu.weatherinfo.service.ServiceCommunicator;
import com.sudhansu.weatherinfo.util.Util;
import com.sudhansu.weatherinfo.util.WeatherDetails;
import com.sudhansu.weatherinfo.service.WeatherLocationService;

import javax.inject.Inject;

import static android.content.Context.BIND_AUTO_CREATE;

public class WeatherPresenter implements WeatherContract.Presenter, ServiceConnection, ServiceCommunicator {

    private WeatherContract.View weatherView;
    private WeatherContract.Model weatherModel;
    private WeatherLocationService weatherLocationService;
    @Inject Context context;

    @Inject
    public WeatherPresenter(WeatherContract.View weatherView, WeatherContract.Model weatherModel) {
        this.weatherView = weatherView;
        this.weatherModel = weatherModel;
    }

    @Override
    public void initialiseWeatherInfo() {
        weatherView.checkLocationPermission();
    }

    @Override
    public void startWeatherInfoService() {
        if (!Util.isJobServiceOn(context)) {
            Intent intentData = new Intent(context, WeatherLocationService.class);
            context.bindService(intentData, this, BIND_AUTO_CREATE);
        } else {
            if (weatherView != null) {
                weatherView.onSuccess(weatherModel.updateWeatherFromPref(context));
            }
        }
    }

    @Override
    public void reStartWeatherInfoService() {
        Intent intentData = new Intent(context, WeatherLocationService.class);
        context.bindService(intentData, this, BIND_AUTO_CREATE);
    }

    @Override
    public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        weatherLocationService = ((WeatherLocationService.ServiceBinder) iBinder).getService();
        weatherLocationService.setServiceCommunicator(this);
    }

    @Override
    public void onServiceDisconnected(ComponentName componentName) {
        weatherLocationService.setServiceCommunicator(null);
    }

    @Override
    public void enableGPSLocation() {
        weatherView.enableGpsLocation();
    }

    @Override
    public void sendWeatherData(WeatherDetails weatherDetails) {
        weatherModel.setWeatherToPref(context, weatherDetails);

        if (weatherView != null) {
            weatherView.onSuccess(weatherDetails);
        }
    }

    @Override
    public void unbindWeatherService() {
        context.unbindService(this);
    }

}

