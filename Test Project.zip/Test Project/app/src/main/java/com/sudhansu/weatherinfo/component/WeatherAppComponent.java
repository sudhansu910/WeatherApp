package com.sudhansu.weatherinfo.component;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.Context;

import com.sudhansu.weatherinfo.WeatherApplication;
import com.sudhansu.weatherinfo.module.WeatherAppModule;
import com.sudhansu.weatherinfo.module.WeatherNetworkModule;

import com.sudhansu.weatherinfo.retrofit.WeatherApiInterface;

import javax.inject.Singleton;

import dagger.Component;

@Singleton
@Component(modules={WeatherAppModule.class, WeatherNetworkModule.class})
public interface WeatherAppComponent {
    void inject(WeatherApplication weatherApplication);

    WeatherApiInterface getWeatherApiInterface();
    Context getApplicationContext();
    JobInfo getJobInfo();
    JobScheduler getJobScheduler();
}
