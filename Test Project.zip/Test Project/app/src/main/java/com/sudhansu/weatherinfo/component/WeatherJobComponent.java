package com.sudhansu.weatherinfo.component;


import com.sudhansu.weatherinfo.module.WeatherJobModule;
import com.sudhansu.weatherinfo.scope.WeatherAPPScope;
import com.sudhansu.weatherinfo.service.WeatherJobService;

import dagger.Component;

@WeatherAPPScope
@Component(modules = { WeatherJobModule.class})
public interface WeatherJobComponent {
    void inject(WeatherJobService weatherJobService);
}
