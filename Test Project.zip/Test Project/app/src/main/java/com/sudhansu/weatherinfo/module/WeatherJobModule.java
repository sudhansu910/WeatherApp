package com.sudhansu.weatherinfo.module;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;

import com.sudhansu.weatherinfo.mvp.WeatherModel;
import com.sudhansu.weatherinfo.scope.WeatherAPPScope;
import com.sudhansu.weatherinfo.service.WeatherJobService;
import com.sudhansu.weatherinfo.util.Util;

import dagger.Module;
import dagger.Provides;

@Module
public class WeatherJobModule {

    private Context context;

    public WeatherJobModule(Context context){
        this.context = context;
    }

    @Provides
    @WeatherAPPScope
    WeatherModel provideWeatherModel(){
        return new WeatherModel();
    }

    @Provides
    @WeatherAPPScope
    JobScheduler provideWeatherJobScheduler(){
        return  (JobScheduler) context.getSystemService( Context.JOB_SCHEDULER_SERVICE );
    }

    @Provides
    @WeatherAPPScope
    JobInfo provideWeatherJobInfoService() {
        return new JobInfo.Builder(Util.JOB_ID, new ComponentName(context, WeatherJobService.class.getName()))
                .setMinimumLatency(Util.REFRESH_INTERVAL)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .build();
    }

}
