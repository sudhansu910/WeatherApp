package com.sudhansu.weatherinfo.component;

import com.sudhansu.weatherinfo.module.WeatherServiceModule;
import com.sudhansu.weatherinfo.scope.WeatherAPPScope;
import com.sudhansu.weatherinfo.service.WeatherLocationService;

import dagger.Component;

@WeatherAPPScope
@Component(dependencies = WeatherAppComponent.class, modules={WeatherServiceModule.class})
public interface WeatherServiceComponent {
    void inject(WeatherLocationService weatherLocationService);
}


