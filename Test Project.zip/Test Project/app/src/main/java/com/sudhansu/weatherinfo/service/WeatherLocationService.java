package com.sudhansu.weatherinfo.service;

import android.Manifest;
import android.app.Service;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.sudhansu.weatherinfo.WeatherApplication;
import com.sudhansu.weatherinfo.component.DaggerWeatherServiceComponent;
import com.sudhansu.weatherinfo.module.WeatherServiceModule;
import com.sudhansu.weatherinfo.retrofit.WeatherApiInterface;
import com.sudhansu.weatherinfo.util.Util;
import com.sudhansu.weatherinfo.util.WeatherDetails;

import javax.inject.Inject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class WeatherLocationService extends Service implements GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener, LocationListener{

    private static final String TAG = WeatherLocationService.class.getSimpleName();

    private GoogleApiClient mLocationClient;
    private ServiceBinder serviceBinder = new ServiceBinder();
    private ServiceCommunicator serviceCommunicator;

    @Inject Context context;
    @Inject JobScheduler jobScheduler;
    @Inject JobInfo jobInfo;
    @Inject WeatherApiInterface weatherApiInterface;
    @Inject LocationRequest mLocationRequest;
    @Inject LocationManager locationManager;

    @Override
    public void onCreate() {
        super.onCreate();
        Log.v(TAG, "onCreate");

        DaggerWeatherServiceComponent.builder().weatherAppComponent(WeatherApplication.get(this).getWeatherAppComponent())
                .weatherServiceModule(new WeatherServiceModule(this)).build()
                .inject(this);

        mLocationClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();

        mLocationRequest.setInterval(1000);
        mLocationRequest.setFastestInterval(1000);
        int priority = LocationRequest.PRIORITY_HIGH_ACCURACY;
        mLocationRequest.setPriority(priority);

        if(mLocationClient != null){
            mLocationClient.connect();
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return serviceBinder;
    }

    public void setServiceCommunicator(ServiceCommunicator callBack) {
         serviceCommunicator = callBack;
    }


    @Override
    public void onConnected(Bundle dataBundle) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
             Log.d(TAG, "== Error On onConnected() Permission not granted");
            return;
        }
        try {
            if(!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)){
                serviceCommunicator.enableGPSLocation();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        LocationServices.FusedLocationApi.requestLocationUpdates(mLocationClient, mLocationRequest, this);

    }

    @Override
    public void onConnectionSuspended(int i) {
        Log.d(TAG, "Connection suspended");
    }

    @Override
    public void onLocationChanged(Location location) {
        Log.d(TAG, "Location changed");
        if (location != null) {
             Call<WeatherDetails> post = weatherApiInterface.getWeatherDetails(location.getLatitude(), location.getLongitude(), Util.WEATHER_KEY, Util.WEATHER_UNIT);
             post.enqueue(new Callback<WeatherDetails>() {

                 @Override
                public void onResponse(Call<WeatherDetails> call, Response<WeatherDetails> response) {
                    serviceCommunicator.sendWeatherData(response.body());
                }

                @Override
                public void onFailure(Call<WeatherDetails> call, Throwable t) {
                    Log.v(TAG, "Failure>>> "+t.getMessage());
                }
            });
            jobScheduler.schedule(jobInfo);

            serviceCommunicator.unbindWeatherService();
        }
    }


    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {
        Log.d(TAG, "Failed to connect to Google API");
    }


    public class ServiceBinder extends Binder {
        public WeatherLocationService getService() {
            return WeatherLocationService.this;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "Destroyed");
        if(mLocationClient.isConnected()) {
            LocationServices.FusedLocationApi.removeLocationUpdates(mLocationClient, this);
            mLocationClient.disconnect();
        }
    }
}
