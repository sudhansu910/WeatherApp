package com.sudhansu.weatherinfo.module;

import android.app.Application;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import com.sudhansu.weatherinfo.WeatherApplication;
import com.sudhansu.weatherinfo.util.Util;
import com.sudhansu.weatherinfo.service.WeatherJobService;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

@Module
public class WeatherAppModule {

    private WeatherApplication weatherApplication;

    public WeatherAppModule(WeatherApplication weatherApplication){
        this.weatherApplication = weatherApplication;
    }

    @Provides
    @Singleton
    public Application provideWeatherApplication() {
        return weatherApplication;
    }


    @Provides
    @Singleton
    Context provideWeatherApplicationContext() {
        return weatherApplication.getApplicationContext();
    }

    @Provides
    @Singleton
    SharedPreferences provideSharedPreference() {
        return PreferenceManager.getDefaultSharedPreferences(weatherApplication);
    }

    @Provides
    @Singleton
    public SharedPreferences.Editor provideSharedPrefEditor(){
        return this.provideSharedPreference().edit();
    }

    @Provides
    @Singleton
    JobScheduler provideWeatherJobScheduler() {
        return (JobScheduler) weatherApplication.getSystemService( Context.JOB_SCHEDULER_SERVICE );
    }


    @Provides
    @Singleton
    JobInfo provideWeatherJobInfoService() {
        return new JobInfo.Builder(Util.JOB_ID, new ComponentName( weatherApplication, WeatherJobService.class.getName()))
                .setMinimumLatency(Util.REFRESH_INTERVAL)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .build();
    }

}
