package com.sudhansu.weatherinfo.util;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class WeatherDetails{

    @SerializedName("name")
    @Expose
    private String name = "";

    @SerializedName("dt")
    @Expose
    private String dt = "";

    @SerializedName("temp")
    @Expose
    private String temp = "";

    @SerializedName("feels_like")
    @Expose
    private String feels_like = "";

    @SerializedName("main")
    @Expose
    private String main = "";

    @SerializedName("description")
    @Expose
    private String description = "";

    @SerializedName("temp_min")
    @Expose
    private String temp_min = "";

    @SerializedName("temp_max")
    @Expose
    private String temp_max = "";

    @SerializedName("pressure")
    @Expose
    private String pressure = "";

    @SerializedName("humidity")
    @Expose
    private String humidity = "";

    @SerializedName("speed")
    @Expose
    private String speed = "";

    @SerializedName("deg")
    @Expose
    private String deg = "";

    @SerializedName("sunrise")
    @Expose
    private String sunrise = "";

    @SerializedName("sunset")
    @Expose
    private String sunset = "";

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDt() {
        return dt;
    }

    public void setDt(String dt) {
        this.dt = dt;
    }

    public String getTemp() {
        return temp;
    }

    public void setTemp(String temp) {
        this.temp = temp;
    }

    public String getFeels_like() {
        return feels_like;
    }

    public void setFeels_like(String feels_like) {
        this.feels_like = feels_like;
    }

    public String getMain() {
        return main;
    }

    public void setMain(String main) {
        this.main = main;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTemp_min() {
        return temp_min;
    }

    public void setTemp_min(String temp_min) {
        this.temp_min = temp_min;
    }

    public String getTemp_max() {
        return temp_max;
    }

    public void setTemp_max(String temp_max) {
        this.temp_max = temp_max;
    }

    public String getPressure() {
        return pressure;
    }

    public void setPressure(String pressure) {
        this.pressure = pressure;
    }

    public String getHumidity() {
        return humidity;
    }

    public void setHumidity(String humidity) {
        this.humidity = humidity;
    }

    public String getSpeed() {
        return speed;
    }

    public void setSpeed(String speed) {
        this.speed = speed;
    }

    public String getDeg() {
        return deg;
    }

    public void setDeg(String deg) {
        this.deg = deg;
    }

    public String getSunrise() {
        return sunrise;
    }

    public void setSunrise(String sunrise) {
        this.sunrise = sunrise;
    }

    public String getSunset() {
        return sunset;
    }

    public void setSunset(String sunset) {
        this.sunset = sunset;
    }
}
