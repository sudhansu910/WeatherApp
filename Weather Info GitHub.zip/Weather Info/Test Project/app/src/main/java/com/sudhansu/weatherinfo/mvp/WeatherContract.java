package com.sudhansu.weatherinfo.mvp;

import android.content.Context;

import com.sudhansu.weatherinfo.util.WeatherDetails;

public interface WeatherContract {

    interface View {
        void checkLocationPermission();
        void enableGpsLocation();
        void onSuccess(WeatherDetails weatherDetails);
        void onFailure(String msg);
    }

    interface Model{
        void setWeatherToPref(Context context, WeatherDetails weatherDetails);
        WeatherDetails updateWeatherFromPref(Context context);
    }

    interface Presenter {
        void initialiseWeatherInfo();
        void startWeatherInfoService();
        void reStartWeatherInfoService();
    }
}
