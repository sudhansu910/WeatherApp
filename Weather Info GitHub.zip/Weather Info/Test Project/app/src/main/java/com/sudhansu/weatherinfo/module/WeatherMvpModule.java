package com.sudhansu.weatherinfo.module;


import android.content.Context;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.sudhansu.weatherinfo.mvp.WeatherContract;

import dagger.Module;
import dagger.Provides;

@Module
public class WeatherMvpModule {

    private WeatherContract.View weatherView;
    private WeatherContract.Model weatherModel;

    public WeatherMvpModule(WeatherContract.View weatherView, WeatherContract.Model weatherModel) {
        this.weatherView = weatherView;
        this.weatherModel = weatherModel;
    }

    @Provides
    public WeatherContract.View provideWeatherView() {
        return weatherView;
    }

    @Provides
    public WeatherContract.Model provideWeatherModel() {
        return weatherModel;
    }

    @Provides
    GoogleApiClient provideGoogleApiClient(Context context){
        return new GoogleApiClient.Builder(context).addApi(LocationServices.API).build();
    }

    @Provides
    LocationSettingsRequest.Builder provideLocationSettingRequest(LocationRequest locationRequest){
       return new LocationSettingsRequest.Builder().setAlwaysShow(true).addLocationRequest(locationRequest);
    }

    @Provides
    LocationRequest provideLocationRequest(){
        LocationRequest locationRequest = LocationRequest.create();
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        locationRequest.setInterval(10000);
        locationRequest.setFastestInterval(10000 / 2);

        return locationRequest;
    }

}
