package com.sudhansu.weatherinfo.util;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class Util {

    public static final int JOB_ID = 1002;
    public static final String WEATHER_BASE_URL = "https://api.openweathermap.org/";
    public static final String WEATHER_KEY = "5ad7218f2e11df834b0eaf3a33a39d2a";
    public static final String WEATHER_UNIT = "metric";
    public static final String weather_Job_scheduler_broadcast = "weather_Job_scheduler_broadcast";

    public static final int REFRESH_INTERVAL = 2* 60 * 60 * 1000; //2 hours

    public static boolean isWifiConnected(Context context){
        ConnectivityManager connManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo mWifi = connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        if (mWifi.isConnected()) {
            return  true;
        }
        return false;
    }

    public static boolean isJobServiceOn( Context context ) {
        JobScheduler scheduler = (JobScheduler) context.getSystemService( Context.JOB_SCHEDULER_SERVICE ) ;
        boolean hasBeenScheduled = false ;
        for ( JobInfo jobInfo : scheduler.getAllPendingJobs() ) {
            if ( jobInfo.getId() == Util.JOB_ID ) {
                hasBeenScheduled = true ;
                break ;
            }
        }
        return hasBeenScheduled ;
    }

}
