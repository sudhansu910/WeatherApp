package com.sudhansu.weatherinfo.module;

import android.content.Context;
import android.location.LocationManager;
import com.google.android.gms.location.LocationRequest;
import com.sudhansu.weatherinfo.service.WeatherLocationService;

import dagger.Module;
import dagger.Provides;

@Module
public class WeatherServiceModule {

    WeatherLocationService mService;

    public WeatherServiceModule(WeatherLocationService service) {
        mService = service;
    }

    @Provides
    public WeatherLocationService provideLocationService() {
        return mService;
    }

    @Provides
    public LocationRequest provideLocationRequest(){
        return new LocationRequest();
    }

    @Provides
    public LocationManager provideLocationManager(){
        return (LocationManager) mService.getSystemService(Context.LOCATION_SERVICE);
    }

}
