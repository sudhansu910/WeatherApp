package com.sudhansu.weatherinfo.util;

import android.content.Context;

import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.sudhansu.weatherinfo.R;

import java.lang.reflect.Type;

public class WeatherDeserializer implements JsonDeserializer<WeatherDetails> {

    public Context context;

    public WeatherDeserializer(Context context){
        this.context = context;
    }

    @Override
    public WeatherDetails deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        final JsonObject jsonObject = json.getAsJsonObject();
        
        JsonObject jsonObjectMain, jsonObjWind, jsonObjSys, jsonObjWeather;
        JsonArray jsonArrayWeather;
        WeatherDetails weatherDetails = new WeatherDetails();

        weatherDetails.setName(jsonObject.get("name").getAsString());
        weatherDetails.setDt(jsonObject.get("dt").getAsString());

        jsonObjectMain = jsonObject.get("main").getAsJsonObject();
        weatherDetails.setTemp(jsonObjectMain.get("temp").getAsString()+this.context.getResources().getString(R.string.degree_only));
        weatherDetails.setFeels_like("Feels like: "+jsonObjectMain.get("feels_like").getAsString()+this.context.getResources().getString(R.string.degree_only));
        weatherDetails.setTemp_min("Min Temp\n"+jsonObjectMain.get("temp_min").getAsString()+this.context.getResources().getString(R.string.degree_only));
        weatherDetails.setTemp_max("Max Temp\n"+jsonObjectMain.get("temp_max").getAsString()+this.context.getResources().getString(R.string.degree_only));
        weatherDetails.setPressure("Pressure\n"+jsonObjectMain.get("pressure").getAsString());
        weatherDetails.setHumidity("Humidity\n"+jsonObjectMain.get("humidity").getAsString());

        jsonObjWind = jsonObject.get("wind").getAsJsonObject();
        weatherDetails.setSpeed("Wind Speed\n"+jsonObjWind.get("speed").getAsString());
        weatherDetails.setDeg("Wind Degree\n"+jsonObjWind.get("deg").getAsString());

        jsonObjSys = jsonObject.get("sys").getAsJsonObject();
        weatherDetails.setSunrise("Sunrise\n"+jsonObjSys.get("sunrise").getAsString());
        weatherDetails.setSunset("Sunset\n"+jsonObjSys.get("sunset").getAsString());

        jsonArrayWeather = jsonObject.get("weather").getAsJsonArray();
        jsonObjWeather = jsonArrayWeather.get(0).getAsJsonObject();

        weatherDetails.setMain(jsonObjWeather.get("main").getAsString());
        weatherDetails.setDescription(jsonObjWeather.get("description").getAsString());

        return weatherDetails;
    }
}
