package com.sudhansu.weatherinfo.module;


import android.content.Context;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.sudhansu.weatherinfo.retrofit.WeatherApiInterface;
import com.sudhansu.weatherinfo.util.Util;
import com.sudhansu.weatherinfo.util.WeatherDeserializer;
import com.sudhansu.weatherinfo.util.WeatherDetails;

import java.lang.reflect.Type;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Converter;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

@Module
public class WeatherNetworkModule {

    @Provides
    WeatherApiInterface provideWeatherApiInterface(Retrofit retrofit){
        return retrofit.create(WeatherApiInterface.class);
    }

    @Provides
    @Singleton
    Gson provideWeatherGson() {
        GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES);
        return gsonBuilder.create();
    }


    @Provides
    @Singleton
    Retrofit provideWeatherRetrofit(OkHttpClient okHttpClient, Converter.Factory weatherConverterFactory) {
        return new Retrofit.Builder()
                .baseUrl(Util.WEATHER_BASE_URL)
                .addConverterFactory(weatherConverterFactory)
                .client(okHttpClient)
                .build();
    }

    @Provides
    @Singleton
    public Converter.Factory createWeatherGsonConverter(Type type, Object typeAdapter) {
        GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.registerTypeAdapter(type, typeAdapter);
        Gson gson = gsonBuilder.create();

        return GsonConverterFactory.create(gson);
    }

    @Provides
    @Singleton
    public Type provideType(){
        return WeatherDetails.class;
    }

    @Provides
    @Singleton
    public Object provideTypeAdapter(Context context){
        return new WeatherDeserializer(context);
    }

    @Provides
    @Singleton
    OkHttpClient getOkHttpCleint(HttpLoggingInterceptor httpLoggingInterceptor) {
        return new OkHttpClient.Builder()
                .addInterceptor(httpLoggingInterceptor)
                .build();
    }

    @Provides
    @Singleton
    HttpLoggingInterceptor getHttpLoggingInterceptor() {
        HttpLoggingInterceptor httpLoggingInterceptor = new HttpLoggingInterceptor();
        httpLoggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        return httpLoggingInterceptor;
    }


}
