package com.sudhansu.weatherinfo.service;

import com.sudhansu.weatherinfo.util.WeatherDetails;

public interface ServiceCommunicator {
    void enableGPSLocation();
    void sendWeatherData(WeatherDetails weatherDetails);
    void unbindWeatherService();
}
