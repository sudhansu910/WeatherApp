package com.sudhansu.weatherinfo.retrofit;

import com.sudhansu.weatherinfo.util.WeatherDetails;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface WeatherApiInterface {

   @GET("/data/2.5/weather?")
   Call<WeatherDetails> getWeatherDetails(@Query("lat") double latitude, @Query("lon") double longitude,
                                          @Query("appid") String appid, @Query("unit") String unit);
}
