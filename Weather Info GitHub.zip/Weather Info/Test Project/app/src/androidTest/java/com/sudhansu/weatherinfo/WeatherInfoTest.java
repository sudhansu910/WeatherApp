package com.sudhansu.weatherinfo;

import android.content.Context;
import android.content.res.Resources;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.rule.ActivityTestRule;

import com.sudhansu.weatherinfo.util.WeatherDetails;


import org.junit.Rule;
import org.junit.Test;




import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.junit.Assert.assertEquals;

public class WeatherInfoTest {
    public WeatherDetails weatherDetails;
    public Resources resources;
    public static final String packageName = "com.sudhansu.weatherinfo";

    @Rule
    public ActivityTestRule<MainActivity> mActivityRule = new ActivityTestRule<>(MainActivity.class);

    public WeatherInfoTest(){
        weatherDetails = WeatherApplication.get(ApplicationProvider.getApplicationContext()).getWeatherDetailsFromPref();
        resources = ApplicationProvider.getApplicationContext().getResources();
    }


    @Test
    public void useAppContext() {
        // Context of the app under test.
        Context appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();
        assertEquals(packageName, appContext.getPackageName());
    }

    @Test
    public void testIsLocationIsValid() throws InterruptedException {
        Thread.sleep(3000);
        onView(withId(R.id.currentLocationTv)).check(matches(withText(weatherDetails.getName())));
    }

    @Test
    public void testIsTimeIsValid() throws InterruptedException{
        Thread.sleep(3000);
        onView(withId(R.id.timeDateTv)).check(matches(withText(weatherDetails.getDt())));
    }

    @Test
    public void testIsTemperatureIsValid() throws InterruptedException{
        Thread.sleep(3000);
        onView(withId(R.id.temperatureTv)).check(matches(withText(weatherDetails.getTemp())));
    }

    @Test
    public void testIsFeelsLikeTempIsValid() throws InterruptedException{
        Thread.sleep(3000);
        onView(withId(R.id.feelsLikeTv)).check(matches(withText(weatherDetails.getFeels_like())));
    }


    @Test
    public void testIsDescriptionIsValid() throws InterruptedException{
        Thread.sleep(3000);
        onView(withId(R.id.mainDesriptionTv)).check(matches(withText(weatherDetails.getMain())));
    }

    @Test
    public void testIsSubDesriptionIsValid() throws InterruptedException{
        Thread.sleep(3000);
        onView(withId(R.id.desriptionTv)).check(matches(withText(weatherDetails.getDescription())));
    }

    @Test
    public void testIsMinTempIsValid() throws InterruptedException{
        Thread.sleep(3000);
        onView(withId(R.id.minTempTv)).check(matches(withText(weatherDetails.getTemp_min())));
    }

    @Test
    public void testIsMaxTempIsValid() throws InterruptedException{
        Thread.sleep(3000);
        onView(withId(R.id.maxTempTv)).check(matches(withText(weatherDetails.getTemp_max())));
    }

    @Test
    public void testIsPressureIsValid() throws InterruptedException{
        Thread.sleep(3000);
        onView(withId(R.id.pressureTv)).check(matches(withText(weatherDetails.getPressure())));
    }

    @Test
    public void testIsHumidityIsValid() throws InterruptedException{
        Thread.sleep(3000);
        onView(withId(R.id.humodityTv)).check(matches(withText(weatherDetails.getHumidity())));
    }

    @Test
    public void testIsWindSpeedIsValid() throws InterruptedException{
        Thread.sleep(3000);
        onView(withId(R.id.windSpeedTv)).check(matches(withText(weatherDetails.getSpeed())));
    }

    @Test
    public void testIsWindDegreeIsValid() throws InterruptedException{
        Thread.sleep(3000);
        onView(withId(R.id.windDegreeTv)).check(matches(withText(weatherDetails.getDeg())));
    }

    @Test
    public void testIsSunriseIsValid() throws InterruptedException{
        Thread.sleep(3000);
        onView(withId(R.id.suriseTv)).check(matches(withText(weatherDetails.getSunrise())));
    }

    @Test
    public void testIsSunsetIsValid() throws InterruptedException{
        Thread.sleep(3000);
        onView(withId(R.id.sunsetTv)).check(matches(withText(weatherDetails.getSunset())));
    }


}
